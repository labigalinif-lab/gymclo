# Gymclo — Railway-ready shared gym challenge

This version has server-backed profiles, 4-digit PINs, shared gym attendance, image upload, and persistent photo evidence.

## Deploy on Railway

1. Back up your current `index.html` locally first. Replace the repository's existing website with **all three files** from this package: `package.json`, `server.js`, and `public/index.html` (the subfolder is important). Optional: add `.gitignore` and this `README.md`.
2. Railway → Gymclo service → **Variables**: create `GYMCLO_SETUP_CODE` with a private phrase of at least 12 characters. Create `GYMCLO_SESSION_SECRET` with a separate random secret of at least 32 characters. Do **not** put the secrets in GitHub or screenshots.
3. Railway project canvas → create a **Volume**, attach it to the Gymclo service, and mount it at **`/app/data`**. This stores profile data and images across redeploys. Make sure the volume is mounted before people start using the site.
4. Railway should detect `package.json` and run `npm start`. If not, choose Start Command `npm start`. Remove any old static hosting start command overriding it. Generate or keep your public domain.
5. Open your domain. Enter your name, the one-time setup code you set in Railway Variables, and choose your 4-digit owner PIN. Admin can then add friends; each friend gets a private invitation code to claim their own profile and set their own PIN.
6. Test on two different devices, upload a profile photo, submit a workout photo, and then redeploy. Profiles should remain after redeploy.

## Important

- This is a **new shared database**. Profiles that existed only in your browser `localStorage` cannot automatically be imported. Create profiles afresh on the new server. Don't delete the old copy until you are happy.
- All attendees must use the same Railway domain. Do not open the HTML file locally (it would enter preview/demo mode).
- The Railway Volume is necessary. Without it, profile data can be lost on deployment.
- Profile pictures and photo evidence are compressed in the browser (JPG, PNG and WebP accepted), then stored on Railway. Photos are accessible to logged-in members; only an admin can review evidence.
- This project suits a small private friend group. A 4-digit PIN is weaker than a conventional password, so keep invitations private and consider stronger sign-in if the site later becomes public at scale.
- Consider taking periodic Railway Volume backups.

## Run locally

```bash
export GYMCLO_SETUP_CODE='choose-a-private-long-code'
export GYMCLO_SESSION_SECRET='choose-a-different-very-long-random-secret-value'
npm start
```

Then open http://localhost:3000.
